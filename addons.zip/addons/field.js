console.log("field.js loaded");

function Field(type)
{
    this.type = type;
    this.selected = false;
}


