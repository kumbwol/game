console.log("field.js loaded");

function Field(type)
{
    this.type = type;
    this.selected = false;
    this.stunned = false;
    this.paralyzed = false;
    this.poison_dmg = 0;
    this.promoted = false;
}


