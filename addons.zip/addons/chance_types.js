console.log("chance_types.js loaded");

const LUCK = 0;
const RAGE = 1;