console.log("chance.js loaded");

function Chance(type, modifier)
{
    this.type = type;
    this.modifier = modifier;
}