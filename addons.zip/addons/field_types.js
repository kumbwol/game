console.log("field_types.js loaded");

const NUL = 0; //nothing = empty
const MAN = 1; //mana
const ATT = 2; //attack
const DEF = 3; //defense
const MOV = 4; //move