console.log("ability_types.js loaded");

const NO_ABILITY          = 0;
const KNIGHT_MOVE         = 1;
const DIAGONAL_MOVE       = 2;
const ROTATE_LEFT         = 3;
const ROTATE_RIGHT        = 4;
const MIRROR_HORIZONTALLY = 5;
const MIRROR_VERTICALLY   = 6;
const MAGIC_TO_MOVE       = 7;
const DEFENSE_TO_ATTACK   = 8;