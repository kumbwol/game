console.log("skillpattern.js loaded");

function SkillPattern(pattern)
{
    this.pattern = pattern;

    this.getSkillPatternHeight = getSkillPatternHeight;
    this.getSkillPatternWidth  = getSkillPatternWidth;
    this.getSkillPatternValue  = getSkillPatternValue;

    function getSkillPatternValue(x, y)
    {
        return this.pattern[y][x];
    }

    function getSkillPatternHeight()
    {
        return this.pattern.length;
    }

    function getSkillPatternWidth()
    {
        return this.pattern[0].length;
    }
}