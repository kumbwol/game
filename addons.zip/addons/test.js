$(function()
{
    start_program();

    function start_game()
    {
        let battle_table = {
            height: 9,
            width: 9
        };

        let engine = new BattleEngine(battle_table);
        let player = new Player("Kumbi");
        let graphics = new BattleGraphics(battle_table, engine, player);
        let moving_skill = false;

        $("#create_table").on("click", function()
        {
            engine.fillUpTable();
            engine.logTable();
            //var graphics = new BattleGraphics(battle_table.height, battle_table.width);
            graphics.drawSkillBar(player);
            graphics.drawTable(battle_table);
        });

        $("#game_background").on("click", ".attack, .mana, .defense, .move", function()
        {
            //alert($(this).attr("id"));
            //alert(y + " " + x);
            //alert(engine.allow_select);
            if(engine.allow_select)
            {
                let y = ($(this).attr("id"))[2];
                let x = ($(this).attr("id"))[6];
                if(!engine.selectField(y, x))
                {
                    if(engine.table[y][x].selected) graphics.drawSelector($(this).attr("id"));
                    else graphics.deleteSelector($(this).attr("id"));
                }
                else
                {
                    graphics.deleteSelector(engine.selected_field_id);
                    graphics.swapFields(engine);
                    //$(this).animate({"top": "0px", "left": "0px"}, 1000);
                }
            }
        });

        $("#game_background").on("click", "#skill_1", function(ev)
        {
            $("#game_background").append('<div class="selected_skill"></div>');
            $(".selected_skill").css("left", ev.pageX);
            $(".selected_skill").css("top",  ev.pageY);
            $(".selected_skill").css("z-index",  1);
            moving_skill = true;
        });


            $("#game_background").on("mousemove", function(ev)
            {
                if(moving_skill && ev.pageX<960 && ev.pageY<540)
                {
                    $(".selected_skill").css("left", ev.pageX);
                    $(".selected_skill").css("top",  ev.pageY);
                }
            });

    }

    function start_program()
    {
        $.when
        (
            $.getScript("addons/battle_engine.js"),
            $.getScript("addons/battle_graphics.js"),
            $.getScript("addons/player.js"),
            $.getScript("addons/field.js"),
            $.getScript("addons/field_types.js"),
            $.getScript("addons/config.js"),
            $.getScript("addons/skillpattern.js"),
            $.getScript("addons/skill.js"),
            $.Deferred(function( deferred ){
                $( deferred.resolve );
            })
        ).done(function()
        {
            start_game();
        });
    }
});