console.log("config.js loaded");

let swap_animation_speed = 300;